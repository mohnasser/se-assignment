// Userlist data array for filling in info box
var userListData = [];

// DOM Ready =============================================================
$(document).ready(function() {
	console.log("Hello");

    // Populate the user table on initial page load
    populateTable();
   // QuoteFromJS();
//document.querySelector('.post-list-item-header').innerHtml = "Title added with javascript";

});

// Functions =============================================================

// Fill table with data
$('.button').on('click',function(event){
	console.log("QuoteFromDB");
    $.ajax({
        url: 'api/quote',
        success: function (post) {
         // var r = JSON.stringify(post);
            $('.Quote').html(post.author);
            $('.author').html(post.text);
        }
    });
     });
	/*var x = require('public/javascripts/quotes.js');
	var i = x.getQuoteFromJSON();
	$.getJSON(i,function(data){
     var quote = '';
     var author = '';
     quote += data.text;
     author += data.author;

     $("Quote").html(quote);
     $("author").html(author);
	}); */


function populateTable() {

    // Empty content string
    var tableContent = '';

    // jQuery AJAX call for JSON
   /* $.getJSON( '/users/quotes', function( data ) {

    // Stick our user data array into a userlist variable in the global object
    userListData = data;
        // For each item in our JSON, add a table row and cells to the content string
        $.each(data, function(){
            tableContent += '<tr>';
            tableContent += '<td><a href="#" class="linkshowuser" rel="' + this.author + '">' + this.author + '</a></td>';
            tableContent += '<td>' + this.text + '</td>';
            tableContent += '<td><a href="#" class="linkdeleteuser" rel="' + this._id + '">delete</a></td>';
            tableContent += '</tr>';
        });

        // Inject the whole content string into our existing HTML table
        $('#quotes table tbody').html(tableContent);
    });
    */
}


// my code
