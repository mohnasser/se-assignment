/*var express = require('express');
var bodyParser = require('body-parser');
var path =  require('path');
var app =  express();

//view engine setup
app.set('views',path.join(__dirname,'views'));
app.set('view engine','hjs');

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({extended:false}));
app.use(express.static('public'));
require('.routes/users')(app);
*/


var express = require('express');
var path = require('path');
var favicon = require('serve-favicon');
var logger = require('morgan');
var cookieParser = require('cookie-parser');
var bodyParser = require('body-parser');
var x = require('./public/quotes.js');
//var  d = require('./db.js');
//var path  = 
// Database
var mongo = require('mongodb');
var monk = require('monk');
var db = monk('localhost:27017/qoutes');


var app = express();

app.use(express.static(path.join(__dirname, 'public')));
// Make our db accessible to our router

app.use(function(req,res,next){
    req.db = db;
    next();
})

app.get('/api/quote', function(req, res) {
  x.getQuoteFromDB(function(error,quote){
   if(!error){
     res.send(quote);
   }
  });
   
});

app.get('/api/quotes', function(req, res) {
    res.send(x.getQuotesFromDB());
});




module.exports = app;
