var GlobalDB = null;
var x = require('./db.js');




var get = exports.getElementByIndexElseRandom =function (array,index){
	if (index ==null) {
		 var Element = array[Math.floor(Math.random() * array.length)];
		 console.log(Element);
		 return Element;
	}else{
	 var Element2 = array[index];
	  console.log(Element2);
	 return Element2;
}
};

exports.getQuotesFromJSON =function(){
	var fs = require('fs');
	var aa = require('./js/quotes.json');
	var w =  fs.readFileSync(__dirname+'/js/quotes.json');
	var e = JSON.parse(w);
	//console.log(x);
	return e;
	
};


//not complete

exports.getQuoteFromJSON = function(index){

	var quote = require('./js/quotes.json');
	if (index ==null){
		return quote[Math.floor(Math.random() * quote.length)];
		//console.log(quote[Math.floor(Math.random() * quote.length)]);
	}
		
		console.log(quote[index]);
		return exports.getElementByIndexElseRandom(quote,index);
	


}

var gg = exports.seed = function (cb){
	console.log("hello");
	
	var DB = null;
        var qq = exports.getQuotesFromJSON();
        DB = x.db();
        DB.collection("quotes").find().toArray(function(err,result){
        	if (result.length ==0){
        			DB.collection("quotes").insert(qq,function (err, inserted) {
			if (!err){
				GlobalDB = DB;
				cb(err,true);
				console.log("inserted successfully");
	            }else{
	            	cb(err,false);
	            }
	        })
        		}else{
        			cb(err,false);
        		}
        });
	
     return GlobalDB;
	}

	// var db = x.db();
// 	var DB = x.connect = function(cb){
// var collection = DB.get('quotes');
// console.log(collection.find());
// var x = getQuotesFromJSON();
// collection.insert( getQuotesFromJSON());};


var gs = exports.getQuotesFromDB =function(cb){
	if (GlobalDB !=null){
 	GlobalDB.collection("quotes").find().toArray(function(error, quotes) {
 		if (!error){
 			cb(error,quotes);
 		}}
 	)}};

 	// var quotes = GlobalDB.collection("quotes").find();
 	// cb(err,quotes){
 	//  .forEach(function(quotes){
 	//  	GlobalDB.collection.print(quotes);
 	//  	return qoutes;

 	//  });
 	
 

// //not complete	+++++++
var gd = exports.getQuoteFromDB = function(cb, index){
 
  	console.log("we entered getQuoteFromDB");
  	
  	  	var quotes = gs();
  	  	GlobalDB = x.db();
  GlobalDB.collection("quotes").find().toArray(function(error, quotes){
  	var d = get(quotes,index);
  	cb(error,d);
   
  }

 )}

// //getElementByIndexElseRandom([1,2,3,4],0);
// getQuotesFromJSON();
//getQuoteFromJSON();
//gg();
//getQuoteFromDB();
//setTimeout(gd, 1);